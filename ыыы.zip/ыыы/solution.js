console.log('========== TERN2.JS ==========');

function manyChecks() {
    let a = Math.floor(Math.random() * 20) + 1;
    console.log(`a = ${a}`);

    // ВАРИАНТ С IF...ELSE
    let resultIfElse = '';

    if (a > 10) {
        resultIfElse += 'a is bigger than 10';
    } else {
        resultIfElse += 'a is less than or equal to 10 ';
        if (a === 5) {
            resultIfElse += 'an example of a special case';
        }
    }

    if (a === 15) {
        resultIfElse += 'but a is not 15';
    }

    if (a > 5) {
        resultIfElse += 'and a is greater than 5';
    } else {
        resultIfElse += 'and a is less than or equal to 5 ';
    }

    if (a % 2) {
        resultIfElse += ' and a is odd';
    } else {
        resultIfElse += ' and a is even';
    }

    console.log(`Результат (if...else): ${resultIfElse}`);

    // ВАРИАНТ С SWITCH
    let resultSwitch = '';

    switch(true) {
        case a > 10:
            resultSwitch += 'a is bigger than 10';
            break;
        default:
            resultSwitch += 'a is less than or equal to 10 ';
            if (a === 5) {
                resultSwitch += 'an example of a special case';
            }
            break;
    }

    if (a === 15) {
        resultSwitch += 'but a is not 15';
    }

    switch(true) {
        case a > 5:
            resultSwitch += 'and a is greater than 5';
            break;
        default:
            resultSwitch += 'and a is less than or equal to 5 ';
            break;
    }

    switch(a % 2) {
        case 1:
            resultSwitch += ' and a is odd';
            break;
        default:
            resultSwitch += ' and a is even';
            break;
    }

    console.log(`Результат (switch): ${resultSwitch}`);
}

manyChecks();